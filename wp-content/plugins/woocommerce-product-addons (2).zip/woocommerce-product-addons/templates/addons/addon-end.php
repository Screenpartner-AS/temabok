	<?php do_action( 'wc_product_addon_end', $addon ); ?>
</div>
